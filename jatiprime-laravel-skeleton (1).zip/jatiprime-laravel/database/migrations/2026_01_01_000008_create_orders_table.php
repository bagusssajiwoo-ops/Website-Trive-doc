<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Ref: 00-entity-relationship.md - address_snapshot disimpan sebagai JSON (bukan hanya FK)
    // agar riwayat pesanan tidak berubah jika data alamat master diedit/dihapus.
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('invoice_no', 30)->unique(); // format JP-YYYYMMDD-XXX
            $table->foreignId('user_id')->constrained('users');
            $table->json('address_snapshot');
            $table->enum('shipping_method', ['reguler', 'express']);
            $table->decimal('shipping_cost', 14, 2)->default(0);
            $table->enum('payment_method', ['transfer_bank', 'cod']);
            $table->enum('status', [
                'menunggu_pembayaran', 'diproses', 'dikirim', 'selesai', 'dibatalkan',
            ])->default('menunggu_pembayaran');
            $table->string('courier_name', 60)->nullable();
            $table->string('resi_no', 60)->nullable();
            $table->decimal('subtotal', 14, 2);
            $table->decimal('total', 14, 2);
            $table->timestamps();

            $table->index(['user_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
