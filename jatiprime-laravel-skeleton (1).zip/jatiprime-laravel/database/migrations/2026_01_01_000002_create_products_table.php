<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Ref: 00-entity-relationship.md - Entity `products`
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('slug', 160)->unique();
            $table->string('name', 160);
            $table->text('description')->nullable();
            $table->decimal('price', 14, 2);
            $table->unsignedInteger('stock')->default(0);
            $table->foreignUuid('category_id')->constrained('categories');
            $table->string('material', 100)->nullable();
            $table->string('finishing', 100)->nullable();
            $table->string('dimension', 100)->nullable();
            $table->string('capacity', 50)->nullable();
            $table->string('warranty', 50)->nullable();
            $table->decimal('rating_avg', 2, 1)->default(0); // computed, updated via observer/job
            $table->unsignedInteger('review_count')->default(0); // computed
            $table->boolean('is_active')->default(true); // soft-visibility flag, see REQ-ADMIN-PRODUK-001
            $table->timestamps();

            $table->index(['category_id', 'is_active']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
