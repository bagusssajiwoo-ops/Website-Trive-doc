<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Ref: home.md — Hero Banner, REQ-HOME-001. Dibuat dinamis via admin (bukan hardcode di frontend).
    public function up(): void
    {
        Schema::create('banners', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('headline', 200);
            $table->string('subheadline', 255)->nullable();
            $table->string('image_url');
            $table->string('cta_label', 60)->default('Jelajahi Koleksi');
            $table->string('cta_url')->default('/produk');
            $table->unsignedInteger('sort_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('banners');
    }
};
