<?php

namespace Database\Seeders;

use App\Models\Faq;
use Illuminate\Database\Seeder;

class FaqSeeder extends Seeder
{
    // Persis 9 pertanyaan yang tampil di mockup FAQ
    public function run(): void
    {
        $faqs = [
            ['q' => 'Apakah produk terbuat dari kayu jati asli?', 'a' => 'Ya, seluruh produk Jati Prime menggunakan kayu jati solid Grade A pilihan.'],
            ['q' => 'Apakah bisa custom ukuran / desain?', 'a' => 'Bisa. Silakan hubungi tim kami via WhatsApp untuk konsultasi gratis custom furniture.'],
            ['q' => 'Berapa lama proses pengerjaan furniture?', 'a' => 'Untuk produk ready stock 3-5 hari kerja, untuk custom 2-6 minggu tergantung kompleksitas desain.'],
            ['q' => 'Bagaimana cara perawatan furniture jati?', 'a' => 'Lap dengan kain kering secara berkala dan hindari paparan air langsung dalam waktu lama.'],
            ['q' => 'Apakah ada garansi produk?', 'a' => 'Semua produk kami memiliki garansi hingga 5 tahun tergantung jenis produk.'],
            ['q' => 'Bagaimana cara pemesanan?', 'a' => 'Pilih produk, tambahkan ke keranjang, lalu ikuti proses checkout hingga pembayaran.'],
            ['q' => 'Apakah bisa COD (Bayar di Tempat)?', 'a' => 'Bisa untuk area tertentu, akan otomatis muncul sebagai opsi pembayaran di checkout jika tersedia.'],
            ['q' => 'Kirim ke luar kota / luar negeri bisa?', 'a' => 'Bisa, kami melayani pengiriman ke seluruh Indonesia dan beberapa negara tujuan ekspor.'],
            ['q' => 'Bagaimana jika barang rusak saat pengiriman?', 'a' => 'Hubungi kami maksimal 2x24 jam setelah barang diterima untuk proses klaim garansi pengiriman.'],
        ];

        foreach ($faqs as $i => $item) {
            Faq::create([
                'question' => $item['q'],
                'answer' => $item['a'],
                'sort_order' => $i,
            ]);
        }
    }
}
