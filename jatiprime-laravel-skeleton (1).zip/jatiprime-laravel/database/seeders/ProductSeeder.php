<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use App\Models\ProductImage;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ProductSeeder extends Seeder
{
    // Data contoh persis nama & harga yang muncul di mockup Home/Produk/Detail Produk
    public function run(): void
    {
        $products = [
            ['name' => 'Meja Makan Jati Solid', 'category' => 'Meja Makan', 'price' => 14800000, 'rating' => 4.9, 'reviews' => 73, 'capacity' => '6 Kursi'],
            ['name' => 'Sofa Tamu Minimalis', 'category' => 'Sofa', 'price' => 8750000, 'rating' => 4.8, 'reviews' => 96, 'capacity' => null],
            ['name' => 'Lemari 3 Pintu Jati', 'category' => 'Lemari', 'price' => 10500000, 'rating' => 4.9, 'reviews' => 41, 'capacity' => null],
            ['name' => 'Tempat Tidur Jati Natural', 'category' => 'Tempat Tidur', 'price' => 9250000, 'rating' => 4.9, 'reviews' => 58, 'capacity' => null],
            ['name' => 'Kursi Makan Jati Anyaman', 'category' => 'Kursi', 'price' => 2250000, 'rating' => 4.8, 'reviews' => 30, 'capacity' => null],
        ];

        foreach ($products as $p) {
            $category = Category::where('name', $p['category'])->first();

            $product = Product::create([
                'slug' => Str::slug($p['name']),
                'name' => $p['name'],
                'description' => "Produk premium berbahan kayu jati solid Grade A, finishing natural oil yang menonjolkan serat kayu asli. Kuat, kokoh, dan tahan hingga puluhan tahun.",
                'price' => $p['price'],
                'stock' => rand(3, 15),
                'category_id' => $category->id,
                'material' => 'Kayu Jati Solid Grade A',
                'finishing' => 'Natural Oil',
                'dimension' => '200 x 100 x 75 cm',
                'capacity' => $p['capacity'],
                'warranty' => '5 Tahun',
                'rating_avg' => $p['rating'],
                'review_count' => $p['reviews'],
                'is_active' => true,
            ]);

            // 2 gambar placeholder per produk
            foreach (range(1, 2) as $i) {
                ProductImage::create([
                    'product_id' => $product->id,
                    'image_url' => "/images/products/{$product->slug}-{$i}.jpg",
                    'sort_order' => $i - 1,
                ]);
            }
        }
    }
}
