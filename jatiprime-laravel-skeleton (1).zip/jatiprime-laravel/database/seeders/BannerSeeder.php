<?php

namespace Database\Seeders;

use App\Models\Banner;
use Illuminate\Database\Seeder;

class BannerSeeder extends Seeder
{
    // Persis teks hero banner di mockup Home
    public function run(): void
    {
        Banner::create([
            'headline' => 'Furniture berkualitas dari kayu jati pilihan untuk melengkapi rumah impian Anda.',
            'subheadline' => 'Desain elegan, kokoh, dan dibuat dengan penuh ketelitian.',
            'image_url' => '/images/banners/hero-1.jpg',
            'cta_label' => 'Jelajahi Koleksi',
            'cta_url' => '/produk',
            'sort_order' => 0,
            'is_active' => true,
        ]);
    }
}
