<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class CategorySeeder extends Seeder
{
    // Data sesuai grid 9 kategori di kategori.md
    public function run(): void
    {
        $categories = [
            'Sofa', 'Meja Makan', 'Kursi', 'Tempat Tidur', 'Lemari',
            'Rak TV', 'Meja Kerja', 'Buffet / Credenza', 'Aksesori',
        ];

        foreach ($categories as $i => $name) {
            Category::create([
                'name' => $name,
                'slug' => Str::slug($name),
                'icon_url' => '/images/categories/'.Str::slug($name).'.svg',
                'sort_order' => $i,
                'is_active' => true,
            ]);
        }
    }
}
