<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    // Jalankan dengan: php artisan db:seed
    public function run(): void
    {
        $this->call([
            CategorySeeder::class,
            ProductSeeder::class,   // bergantung pada CategorySeeder (butuh category_id)
            BannerSeeder::class,
            FaqSeeder::class,
        ]);
    }
}
