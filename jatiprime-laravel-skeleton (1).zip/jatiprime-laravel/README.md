# Jati Prime — Laravel Skeleton (v2)

Skeleton project berdasarkan dokumen SRS (`00-entity-relationship.md`, `00-api-database-mapping.md`, `00-project-architecture.md`), sekarang dengan arsitektur berlapis (Service, Policy, Request, Resource, Observer) supaya controller tetap ringkas walau proyek membesar.

## Tech Stack

| Layer | Teknologi |
|---|---|
| Framework | Laravel 12, PHP 8.3 |
| Admin Panel | Filament 3 (auto-CRUD dari model) |
| Frontend styling | Tailwind CSS |
| Interaktivitas ringan | Alpine.js, Livewire 3 (dipakai otomatis oleh Filament) |
| Database | MySQL |
| Auth API | Sanctum |
| Role & Permission | Spatie Laravel-Permission (dipakai middleware `role:admin` di `routes/api.php`) |
| Image processing | Intervention Image (resize/crop upload produk sebelum simpan) |
| Storage gambar | Cloudflare R2 (S3-compatible) — lihat langkah 8 |
| Testing | PestPHP |
| Code style | Laravel Pint |

## Langkah Setup

### 1. Buat project & install dependency
```bash
composer create-project laravel/laravel jatiprime
cd jatiprime

composer require laravel/sanctum
composer require filament/filament:"^3.0"
composer require spatie/laravel-permission
composer require intervention/image
composer require league/flysystem-aws-s3-v3 "^3.0"   # driver S3-compatible untuk R2
composer require pestphp/pest --dev --with-all-dependencies
composer require laravel/pint --dev

npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

### 2. Copy semua file dari skeleton ini ke project
```
app/Models/*.php                      → app/Models/
app/Services/*.php                    → app/Services/         (baru)
app/Policies/*.php                    → app/Policies/          (baru)
app/Http/Requests/*.php               → app/Http/Requests/     (baru)
app/Http/Resources/*.php              → app/Http/Resources/    (baru)
app/Observers/*.php                   → app/Observers/         (baru)
app/Exceptions/*.php                  → app/Exceptions/        (baru)
app/Http/Controllers/Api/*.php        → app/Http/Controllers/Api/
database/migrations/*.php             → database/migrations/
database/seeders/*.php                → database/seeders/      (baru)
routes/api.php                        → replace routes/api.php
```

> Folder `app/Actions` & `app/Traits` sudah disiapkan tapi masih kosong — isi sesuai kebutuhan kamu nanti (contoh Action: `CalculateShippingCostAction`, contoh Trait: `HasSlug` kalau mau reuse logic slug generation di beberapa model).

### 3. Daftarkan Observer
Di `app/Providers/AppServiceProvider.php`, tambahkan di method `boot()`:
```php
use App\Models\Review;
use App\Observers\ReviewObserver;

public function boot(): void
{
    Review::observe(ReviewObserver::class);
}
```

### 4. Daftarkan Policy
Di `app/Providers/AuthServiceProvider.php` (atau `AppServiceProvider` di Laravel 11+):
```php
use App\Models\Order;
use App\Policies\OrderPolicy;

protected $policies = [
    Order::class => OrderPolicy::class,
];
```

### 5. Setup Spatie Permission
```bash
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
php artisan migrate
```
Lalu buat role `admin` & assign ke user pertama kamu (lihat dokumentasi Spatie Permission).

### 6. Setup `.env` — MySQL
```env
DB_CONNECTION=mysql
DB_DATABASE=jatiprime
DB_USERNAME=root
DB_PASSWORD=
```

### 7. Migrate & Seed
```bash
php artisan migrate
php artisan db:seed
```
Setelah ini langsung ada data contoh: 9 kategori, 5 produk (sesuai mockup), 1 hero banner, 9 FAQ.

### 8. Setup Storage — Cloudflare R2 (S3-compatible)
Tambahkan di `config/filesystems.php`, di array `disks`:
```php
'r2' => [
    'driver' => 's3',
    'key' => env('R2_ACCESS_KEY_ID'),
    'secret' => env('R2_SECRET_ACCESS_KEY'),
    'region' => 'auto',
    'bucket' => env('R2_BUCKET'),
    'endpoint' => env('R2_ENDPOINT'), // https://<account_id>.r2.cloudflarestorage.com
    'use_path_style_endpoint' => true,
],
```
Set `FILESYSTEM_DISK=r2` di `.env`, isi kredensial R2 kamu. Upload gambar produk (di Filament Resource) tinggal set `->disk('r2')` pada FileUpload field — supaya VPS tidak penuh oleh gambar produk.

### 9. Setup Filament admin panel
```bash
php artisan filament:install --panels
php artisan make:filament-user
php artisan make:filament-resource Product --generate
php artisan make:filament-resource Category --generate
php artisan make:filament-resource Order --generate
```

### 10. Tailwind config — design tokens dari `00-design-system.md`
Edit `tailwind.config.js`:
```js
module.exports = {
  content: ['./resources/**/*.blade.php'],
  theme: {
    extend: {
      colors: {
        primary: '#6F7863', 'primary-hover': '#5C6552', 'primary-dark': '#4A5142',
        'body-bg': '#F8F5EF', surface: '#FFFFFF', border: '#E5E1D8',
        'text-primary': '#2B2B26', 'text-secondary': '#6B6B63',
        success: '#3E8E5A', warning: '#E0A93E', danger: '#E53935',
        info: '#3B6EA5', 'rating-star': '#F5B301',
      },
      borderRadius: { sm: '8px', md: '12px', lg: '16px', xl: '18px' },
      fontFamily: {
        display: ['Playfair Display', 'Georgia', 'serif'],
        sans: ['Inter', 'sans-serif'],
      },
    },
  },
};
```

## Struktur Project Sekarang

```
app/
├── Models/          13 Eloquent model + Banner (relasi lengkap)
├── Services/         CartService, OrderService — business logic
├── Policies/          OrderPolicy — otorisasi
├── Http/
│   ├── Requests/      StoreOrderRequest, UpdateCartItemRequest — validasi
│   ├── Resources/      ProductResource, OrderResource — bentuk output JSON
│   └── Controllers/Api/ ProductController, CartController, OrderController (tipis!)
├── Observers/          ReviewObserver — auto-update rating_avg produk
├── Exceptions/          InsufficientStockException, EmptyCartException
├── Actions/             (kosong, siap dipakai)
└── Traits/              (kosong, siap dipakai)

database/
├── migrations/        14 tabel (13 dari ERD + banners)
└── seeders/            CategorySeeder, ProductSeeder, BannerSeeder, FaqSeeder, DatabaseSeeder

routes/api.php          Semua endpoint sesuai 00-api-database-mapping.md
```

## Contoh Alur: Tambah ke Keranjang

```
Request masuk → CartController::store()
   → validasi request (product_id, qty)
   → panggil CartService::addItem()
        → cek stok, throw InsufficientStockException kalau tidak cukup
        → simpan/update CartItem
   → controller kembalikan response
```
Controller tidak pernah menyentuh query DB langsung — itu tugas Service & Model. Ini yang bikin controller tetap pendek walau fitur bertambah banyak.

## Langkah Selanjutnya (Belum Dibuatkan, PR Kamu)
- [ ] `AuthController` (register, login, logout) — pakai Sanctum
- [ ] `HomeController`, `CategoryController`, `WishlistController`, `ReviewController`, `FaqController`, `GalleryController`
- [ ] Semua `Api/Admin/*Controller` — atau **skip**, pakai Filament Resource (langkah 9) yang auto-generate CRUD
- [ ] Blade component sesuai `00-component-library.md` (`<x-button>`, `<x-card>`, dst)
- [ ] `CartItemPolicy` (dipakai di `CartController::destroy`)
- [ ] Pasang Intervention Image di FileUpload Filament untuk resize gambar produk sebelum upload ke R2
- [ ] Tulis test PestPHP dasar untuk `OrderService::createFromCart()` (paling kritis — ada logic stok & transaksi)
- [ ] Jalankan `./vendor/bin/pint` sebelum commit untuk auto-format code style
