<?php

namespace App\Policies;

use App\Models\Order;
use App\Models\User;

class OrderPolicy
{
    // Dipakai di OrderController: $this->authorize('view', $order)
    public function view(User $user, Order $order): bool
    {
        return $user->id === $order->user_id || $user->hasRole('admin'); // hasRole dari Spatie Permission
    }

    // REQ-PESANAN-003: batalkan pesanan hanya boleh oleh pemilik & hanya saat status masih "diproses"/"menunggu_pembayaran"
    public function cancel(User $user, Order $order): bool
    {
        return $user->id === $order->user_id
            && in_array($order->status, [Order::STATUS_MENUNGGU_PEMBAYARAN, Order::STATUS_DIPROSES]);
    }
}
