<?php

namespace App\Observers;

use App\Models\Review;

// Ref: Developer Notes di 00-entity-relationship.md —
// "rating_avg & review_count sebaiknya computed/cached, di-update via background job/observer,
//  jangan dihitung real-time di setiap request Detail Produk."
// Daftarkan di AppServiceProvider::boot(): Review::observe(ReviewObserver::class);
class ReviewObserver
{
    public function created(Review $review): void
    {
        $this->recalculate($review);
    }

    public function updated(Review $review): void
    {
        $this->recalculate($review);
    }

    public function deleted(Review $review): void
    {
        $this->recalculate($review);
    }

    private function recalculate(Review $review): void
    {
        if (! $review->product_id) {
            return; // review toko keseluruhan, bukan review produk spesifik
        }

        $product = $review->product;
        $stats = $product->reviews()->selectRaw('AVG(rating) as avg_rating, COUNT(*) as total')->first();

        $product->update([
            'rating_avg' => round($stats->avg_rating ?? 0, 1),
            'review_count' => $stats->total ?? 0,
        ]);
    }
}
