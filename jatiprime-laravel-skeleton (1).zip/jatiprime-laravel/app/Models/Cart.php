<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    use HasUuids;

    protected $fillable = ['user_id'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function items()
    {
        return $this->hasMany(CartItem::class);
    }

    // REQ-CART-001: dipakai untuk hitung subtotal real-time
    public function getSubtotalAttribute(): float
    {
        return $this->items->sum(fn ($item) => $item->qty * $item->product->price);
    }
}
