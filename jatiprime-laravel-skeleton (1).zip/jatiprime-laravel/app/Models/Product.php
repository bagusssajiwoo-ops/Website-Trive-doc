<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasUuids;

    protected $fillable = [
        'slug', 'name', 'description', 'price', 'stock', 'category_id',
        'material', 'finishing', 'dimension', 'capacity', 'warranty',
        'rating_avg', 'review_count', 'is_active',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'rating_avg' => 'decimal:1',
        'is_active' => 'boolean',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function images()
    {
        return $this->hasMany(ProductImage::class)->orderBy('sort_order');
    }

    public function reviews()
    {
        return $this->hasMany(Review::class);
    }

    // REQ-DETAIL-005 / REQ-PRODUK-003: dipakai di API untuk mengecek status wishlist user saat ini
    public function wishlistedBy()
    {
        return $this->hasMany(Wishlist::class);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeInStock($query)
    {
        return $query->where('stock', '>', 0);
    }
}
