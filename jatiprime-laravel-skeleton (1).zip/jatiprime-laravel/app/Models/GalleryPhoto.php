<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class GalleryPhoto extends Model
{
    use HasUuids;

    protected $fillable = ['image_url', 'tag', 'related_product_id'];

    public function relatedProduct()
    {
        return $this->belongsTo(Product::class, 'related_product_id');
    }
}
