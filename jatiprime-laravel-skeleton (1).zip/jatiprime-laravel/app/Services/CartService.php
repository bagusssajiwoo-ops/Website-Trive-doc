<?php

namespace App\Services;

use App\Exceptions\InsufficientStockException;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Product;
use App\Models\User;

// Business logic keranjang dipisah dari controller — controller cukup tipis,
// tinggal panggil service ini. Ref saran: "Controller tidak menjadi ribuan baris".
class CartService
{
    public function getOrCreateCart(User $user): Cart
    {
        return $user->cart()->firstOrCreate();
    }

    public function addItem(User $user, Product $product, int $qty): CartItem
    {
        $cart = $this->getOrCreateCart($user);
        $existing = $cart->items()->where('product_id', $product->id)->first();
        $newQty = ($existing->qty ?? 0) + $qty;

        if ($newQty > $product->stock) {
            throw new InsufficientStockException($product, $product->stock);
        }

        return CartItem::updateOrCreate(
            ['cart_id' => $cart->id, 'product_id' => $product->id],
            ['qty' => $newQty]
        );
    }

    public function updateQty(CartItem $item, int $qty): CartItem
    {
        // REQ-CART-002: clamp otomatis ke stok tersedia
        $clamped = min($qty, $item->product->stock);
        $item->update(['qty' => $clamped]);

        return $item->fresh();
    }

    public function removeItem(CartItem $item): void
    {
        $item->delete();
    }
}
