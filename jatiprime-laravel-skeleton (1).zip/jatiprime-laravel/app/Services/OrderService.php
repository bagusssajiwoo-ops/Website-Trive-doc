<?php

namespace App\Services;

use App\Exceptions\EmptyCartException;
use App\Exceptions\InsufficientStockException;
use App\Models\Address;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class OrderService
{
    public function __construct(private CartService $cartService) {}

    /**
     * Ref: REQ-CHECKOUT-003 (idempotency), REQ-CHECKOUT-004 (validasi ulang stok/harga di backend),
     * Data snapshot alamat & harga sesuai Developer Notes di 00-entity-relationship.md
     */
    public function createFromCart(User $user, Address $address, string $shippingMethod, string $paymentMethod): Order
    {
        return DB::transaction(function () use ($user, $address, $shippingMethod, $paymentMethod) {
            $cart = $this->cartService->getOrCreateCart($user)->load('items.product');

            if ($cart->items->isEmpty()) {
                throw new EmptyCartException;
            }

            foreach ($cart->items as $item) {
                if ($item->qty > $item->product->stock) {
                    throw new InsufficientStockException($item->product, $item->product->stock);
                }
            }

            $shippingCost = $shippingMethod === 'express' ? 150000 : 0;
            $subtotal = $cart->subtotal;

            $order = Order::create([
                'invoice_no' => $this->generateInvoiceNumber(),
                'user_id' => $user->id,
                'address_snapshot' => $address->only(['recipient_name', 'phone', 'full_address']),
                'shipping_method' => $shippingMethod,
                'shipping_cost' => $shippingCost,
                'payment_method' => $paymentMethod,
                'status' => Order::STATUS_MENUNGGU_PEMBAYARAN,
                'subtotal' => $subtotal,
                'total' => $subtotal + $shippingCost,
            ]);

            foreach ($cart->items as $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item->product_id,
                    'product_name_snapshot' => $item->product->name,
                    'qty' => $item->qty,
                    'price_at_purchase' => $item->product->price,
                ]);

                $item->product->decrement('stock', $item->qty);
            }

            $cart->items()->delete();

            // TODO: dispatch OrderCreated event → trigger notifikasi WhatsApp/email ke customer (lihat REQ-ADMIN-PESANAN-002)

            return $order->load('items');
        });
    }

    private function generateInvoiceNumber(): string
    {
        $todayCount = Order::whereDate('created_at', now())->count() + 1;

        return 'JP-'.now()->format('Ymd').'-'.Str::padLeft((string) $todayCount, 3, '0');
    }

    public function buildTrackingTimeline(Order $order): array
    {
        $steps = ['menunggu_pembayaran' => 'Pesanan Dibuat', 'diproses' => 'Diproses', 'dikirim' => 'Dikirim', 'selesai' => 'Tiba di Tujuan'];
        $currentIndex = array_search($order->status, array_keys($steps));

        return collect($steps)->values()->map(fn ($label, $i) => [
            'label' => $label,
            'completed' => $i <= $currentIndex,
        ])->all();
    }
}
