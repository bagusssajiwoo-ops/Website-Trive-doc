<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

// Ref: REQ-CHECKOUT-002 — validasi kelengkapan alamat, metode pengiriman & pembayaran sebelum submit
class StoreOrderRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // otorisasi kepemilikan address dicek di rule 'exists' + custom rule di bawah
    }

    public function rules(): array
    {
        return [
            'address_id' => [
                'required',
                'uuid',
                function ($attribute, $value, $fail) {
                    $owned = $this->user()->addresses()->where('id', $value)->exists();
                    if (! $owned) {
                        $fail('Alamat tidak ditemukan atau bukan milik Anda.');
                    }
                },
            ],
            'shipping_method' => 'required|in:reguler,express',
            'payment_method' => 'required|in:transfer_bank,cod',
        ];
    }

    public function messages(): array
    {
        return [
            'address_id.required' => 'Alamat pengiriman wajib dipilih.',
            'shipping_method.required' => 'Metode pengiriman wajib dipilih.',
            'payment_method.required' => 'Metode pembayaran wajib dipilih.',
        ];
    }
}
