<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCartItemRequest extends FormRequest
{
    public function authorize(): bool
    {
        // Pastikan cart item ini milik user yang login
        return $this->route('cartItem')->cart->user_id === $this->user()->id;
    }

    public function rules(): array
    {
        return [
            'qty' => 'required|integer|min:1',
        ];
    }
}
