<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    // GET /api/products?search=&category=&sort=&page=
    // Ref: REQ-PRODUK-001 (search debounce di frontend), REQ-PRODUK-002 (filter tab), REQ-PRODUK-004 (pagination)
    public function index(Request $request)
    {
        $query = Product::query()->active()->with(['category', 'images']);

        if ($request->filled('search')) {
            $query->where('name', 'like', '%'.$request->search.'%');
        }

        if ($request->filled('category')) {
            $query->whereHas('category', fn ($q) => $q->where('slug', $request->category));
        }

        match ($request->input('sort')) {
            'terbaru' => $query->latest(),
            'terlaris' => $query->orderByDesc('review_count'),
            'harga_tertinggi' => $query->orderByDesc('price'),
            default => $query->orderBy('name'),
        };

        return ProductResource::collection($query->paginate(12)); // page size disesuaikan grid 2 kolom mobile
    }

    // GET /api/products/{slug} — bentuk output persis Data Contract "Product" di 00-entity-relationship.md
    public function show(string $slug)
    {
        $product = Product::active()
            ->with(['category', 'images', 'reviews.user'])
            ->where('slug', $slug)
            ->firstOrFail();

        return ProductResource::make($product);
    }
}
