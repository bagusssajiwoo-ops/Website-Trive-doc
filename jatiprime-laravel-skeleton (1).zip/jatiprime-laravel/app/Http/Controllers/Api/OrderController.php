<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreOrderRequest;
use App\Http\Resources\OrderResource;
use App\Models\Address;
use App\Models\Order;
use App\Services\CartService;
use App\Services\OrderService;
use Illuminate\Http\Request;

// Controller tipis — logic checkout & tracking ada di OrderService.
class OrderController extends Controller
{
    public function __construct(
        private OrderService $orderService,
        private CartService $cartService,
    ) {}

    public function checkoutSummary(Request $request)
    {
        $cart = $this->cartService->getOrCreateCart($request->user())->load('items.product');

        return response()->json([
            'address' => $request->user()->addresses()->where('is_default', true)->first(),
            'shipping_methods' => [
                ['code' => 'reguler', 'label' => 'Pengiriman Reguler', 'cost' => 0, 'eta' => '3-5 hari'],
                ['code' => 'express', 'label' => 'Pengiriman Express', 'cost' => 150000, 'eta' => '1-2 hari'],
            ],
            'payment_methods' => ['transfer_bank', 'cod'],
            'subtotal' => $cart->subtotal,
        ]);
    }

    // REQ-CHECKOUT-001..005 — validasi ada di StoreOrderRequest, logic transaksi ada di OrderService
    public function store(StoreOrderRequest $request)
    {
        $address = Address::findOrFail($request->validated('address_id'));

        $order = $this->orderService->createFromCart(
            user: $request->user(),
            address: $address,
            shippingMethod: $request->validated('shipping_method'),
            paymentMethod: $request->validated('payment_method'),
        );

        return OrderResource::make($order)->response()->setStatusCode(201);
    }

    public function index(Request $request)
    {
        $orders = $request->user()->orders()
            ->when($request->status, fn ($q, $status) => $q->where('status', $status))
            ->latest()
            ->paginate(10);

        return OrderResource::collection($orders);
    }

    public function show(Order $order)
    {
        $this->authorize('view', $order);

        return OrderResource::make($order->load('items'));
    }

    public function tracking(Order $order)
    {
        $this->authorize('view', $order);

        return response()->json([
            'timeline' => $this->orderService->buildTrackingTimeline($order),
            'courier' => [
                'name' => $order->courier_name,
                'resi' => $order->resi_no,
            ],
        ]);
    }
}
