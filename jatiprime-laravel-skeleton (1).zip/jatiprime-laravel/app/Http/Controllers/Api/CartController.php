<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateCartItemRequest;
use App\Models\CartItem;
use App\Models\Product;
use App\Services\CartService;
use Illuminate\Http\Request;

// Controller sengaja tipis — semua business logic ada di CartService (app/Services/).
class CartController extends Controller
{
    public function __construct(private CartService $cartService) {}

    public function index(Request $request)
    {
        $cart = $this->cartService->getOrCreateCart($request->user())->load('items.product.images');

        return response()->json([
            'items' => $cart->items,
            'subtotal' => $cart->subtotal,
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'product_id' => 'required|exists:products,id',
            'qty' => 'required|integer|min:1',
        ]);

        $product = Product::findOrFail($data['product_id']);
        $item = $this->cartService->addItem($request->user(), $product, $data['qty']);

        return response()->json($item, 201);
    }

    public function update(UpdateCartItemRequest $request, CartItem $cartItem)
    {
        $item = $this->cartService->updateQty($cartItem, $request->validated('qty'));

        return response()->json($item);
    }

    public function destroy(CartItem $cartItem)
    {
        $this->authorize('delete', $cartItem); // pastikan buat CartItemPolicy jika ingin lebih ketat
        $this->cartService->removeItem($cartItem);

        return response()->noContent();
    }
}
