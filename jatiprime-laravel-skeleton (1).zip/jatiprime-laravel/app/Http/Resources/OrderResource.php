<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

// Bentuk output persis sesuai "Data Contract" Order di 00-entity-relationship.md
class OrderResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'invoice_no' => $this->invoice_no,
            'status' => $this->status,
            'address' => $this->address_snapshot,
            'shipping_method' => $this->shipping_method,
            'shipping_cost' => (float) $this->shipping_cost,
            'payment_method' => $this->payment_method,
            'courier_name' => $this->courier_name,
            'resi_no' => $this->resi_no,
            'items' => $this->items->map(fn ($item) => [
                'product_name' => $item->product_name_snapshot,
                'qty' => $item->qty,
                'price_at_purchase' => (float) $item->price_at_purchase,
            ]),
            'subtotal' => (float) $this->subtotal,
            'total' => (float) $this->total,
            'created_at' => $this->created_at->toIso8601String(),
        ];
    }
}
