<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

// Bentuk output persis sesuai "Data Contract" Product di 00-entity-relationship.md
class ProductResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'slug' => $this->slug,
            'name' => $this->name,
            'description' => $this->description,
            'price' => (float) $this->price,
            'stock' => $this->stock,
            'category' => [
                'id' => $this->category->id,
                'name' => $this->category->name,
                'slug' => $this->category->slug,
            ],
            'images' => $this->images->map(fn ($img) => [
                'url' => $img->image_url,
                'sort_order' => $img->sort_order,
            ]),
            'specs' => [
                'material' => $this->material,
                'finishing' => $this->finishing,
                'dimension' => $this->dimension,
                'capacity' => $this->capacity,
                'warranty' => $this->warranty,
            ],
            'rating_avg' => (float) $this->rating_avg,
            'review_count' => $this->review_count,
            'is_wishlisted' => $request->user()
                ? $this->wishlistedBy()->where('user_id', $request->user()->id)->exists()
                : false,
            'is_active' => $this->is_active,
        ];
    }
}
