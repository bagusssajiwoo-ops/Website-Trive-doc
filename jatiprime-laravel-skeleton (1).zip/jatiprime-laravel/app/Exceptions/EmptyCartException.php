<?php

namespace App\Exceptions;

use Exception;

class EmptyCartException extends Exception
{
    public function __construct()
    {
        parent::__construct('Keranjang kosong, tidak dapat membuat pesanan.');
    }

    public function render()
    {
        return response()->json(['message' => $this->getMessage()], 422);
    }
}
