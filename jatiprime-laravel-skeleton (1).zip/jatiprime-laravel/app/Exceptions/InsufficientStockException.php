<?php

namespace App\Exceptions;

use App\Models\Product;
use Exception;

class InsufficientStockException extends Exception
{
    public function __construct(public Product $product, public int $availableStock)
    {
        parent::__construct("Stok {$product->name} tidak mencukupi. Tersisa: {$availableStock}");
    }

    public function render()
    {
        return response()->json([
            'message' => $this->getMessage(),
            'product_id' => $this->product->id,
            'available_stock' => $this->availableStock,
        ], 422);
    }
}
