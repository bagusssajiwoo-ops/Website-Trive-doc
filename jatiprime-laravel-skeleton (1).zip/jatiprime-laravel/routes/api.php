<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\FaqController;
use App\Http\Controllers\Api\GalleryController;
use App\Http\Controllers\Api\HomeController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\ReviewController;
use App\Http\Controllers\Api\WishlistController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes — Jati Prime
| Ref: 00-api-database-mapping.md
|--------------------------------------------------------------------------
*/

// ── Publik (tanpa auth) ──────────────────────────────────────────
Route::get('/home', [HomeController::class, 'index']);
Route::get('/categories', [CategoryController::class, 'index']);
Route::get('/products', [ProductController::class, 'index']);
Route::get('/products/{slug}', [ProductController::class, 'show']);
Route::get('/faq', [FaqController::class, 'index']);
Route::get('/contact', [HomeController::class, 'contact']);
Route::get('/gallery', [GalleryController::class, 'index']);
Route::get('/reviews', [ReviewController::class, 'index']);
Route::get('/pages/about', [HomeController::class, 'about']);

// ── Auth ─────────────────────────────────────────────────────────
Route::post('/auth/register', [AuthController::class, 'register']); // REQ-REGISTER-*
Route::post('/auth/login', [AuthController::class, 'login']);       // REQ-LOGIN-*, rate-limited

// ── Butuh auth (Sanctum) ────────────────────────────────────────
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/me', [AuthController::class, 'me']);
    Route::post('/auth/logout', [AuthController::class, 'logout']);

    // Wishlist — REQ-WISHLIST-*
    Route::get('/wishlist', [WishlistController::class, 'index']);
    Route::post('/wishlist/{product}', [WishlistController::class, 'toggle']);

    // Cart — REQ-CART-*
    Route::get('/cart', [CartController::class, 'index']);
    Route::post('/cart', [CartController::class, 'store']);
    Route::patch('/cart/{cartItem}', [CartController::class, 'update']);
    Route::delete('/cart/{cartItem}', [CartController::class, 'destroy']);

    // Checkout & Orders — REQ-CHECKOUT-*, REQ-PESANAN-*, REQ-TRACKING-*
    Route::get('/checkout/summary', [OrderController::class, 'checkoutSummary']);
    Route::post('/orders', [OrderController::class, 'store']); // idempotency key wajib di header
    Route::get('/orders', [OrderController::class, 'index']);
    Route::get('/orders/{order}', [OrderController::class, 'show']);
    Route::get('/orders/{order}/tracking', [OrderController::class, 'tracking']);
});

// ── Admin (Sanctum + role:admin) ────────────────────────────────
Route::middleware(['auth:sanctum', 'role:admin'])->prefix('admin')->group(function () {
    Route::get('/stats', [\App\Http\Controllers\Api\Admin\DashboardController::class, 'index']);

    Route::apiResource('products', \App\Http\Controllers\Api\Admin\ProductController::class);
    Route::apiResource('categories', \App\Http\Controllers\Api\Admin\CategoryController::class);

    Route::get('/orders', [\App\Http\Controllers\Api\Admin\OrderController::class, 'index']);
    Route::patch('/orders/{order}', [\App\Http\Controllers\Api\Admin\OrderController::class, 'update']); // REQ-ADMIN-PESANAN-001

    Route::get('/customers', [\App\Http\Controllers\Api\Admin\CustomerController::class, 'index']);
    Route::patch('/customers/{user}', [\App\Http\Controllers\Api\Admin\CustomerController::class, 'update']); // blokir/aktifkan
});
